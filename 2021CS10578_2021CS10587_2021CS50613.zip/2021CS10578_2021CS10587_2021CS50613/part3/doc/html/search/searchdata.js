var indexSectionsWithContent =
{
  0: "acdhiklmnprst",
  1: "hl",
  2: "hlm",
  3: "ahilmr",
  4: "cdhklmnpt",
  5: "ls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

