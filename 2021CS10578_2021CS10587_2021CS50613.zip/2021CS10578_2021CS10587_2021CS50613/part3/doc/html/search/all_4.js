var searchData=
[
  ['is_5fempty_13',['is_empty',['../list_8h.html#a4df754b95439918e8813c67771283a40',1,'is_empty(struct list *l):&#160;list.c'],['../list_8c.html#a4df754b95439918e8813c67771283a40',1,'is_empty(struct list *l):&#160;list.c']]]
];
