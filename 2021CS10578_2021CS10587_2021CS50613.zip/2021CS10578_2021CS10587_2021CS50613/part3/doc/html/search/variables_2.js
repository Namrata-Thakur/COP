var searchData=
[
  ['head_73',['head',['../structlist.html#a9d859e10efc6b77fe2790d27bff17b3d',1,'list']]]
];
