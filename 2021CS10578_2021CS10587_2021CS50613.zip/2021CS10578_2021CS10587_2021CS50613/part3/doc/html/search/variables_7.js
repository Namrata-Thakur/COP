var searchData=
[
  ['prev_79',['prev',['../structlistentry.html#a1de0c68fb0da77657663aea791f13daa',1,'listentry']]]
];
