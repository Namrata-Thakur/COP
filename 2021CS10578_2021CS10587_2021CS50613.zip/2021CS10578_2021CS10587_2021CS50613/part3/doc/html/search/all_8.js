var searchData=
[
  ['next_36',['next',['../structlistentry.html#a9afb253e4f1ccd87a285e84e4ea9609f',1,'listentry']]]
];
