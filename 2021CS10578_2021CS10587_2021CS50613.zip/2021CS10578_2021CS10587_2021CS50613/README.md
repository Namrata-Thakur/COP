# Assignment 2

This assignment currently contains 2 parts
part1 - Here you need to complete functions - conjecture and assert.
part2 - Here you need to complete 3 checkpoints as stated in the assignment document

In part 2, students should not change main.c present in test folder. This file will be used for evaluation.

Students should update makefile. Currently it contains commands for running list tests. To run list tests after completion of list.c file. Run command "make list"

Just like list tag in makefile, students need to create hashmap tag and all tag for running hashmap tests and main test respectively.